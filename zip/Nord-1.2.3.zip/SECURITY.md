# Security Policy

## Supported Versions

Use this section to tell people about which versions of your project are
currently being supported with security updates.

| Version | Supported          |
| ------- | ------------------ |
| 1.0     | :white_check_mark: |
| 1.1.2   | :white_check_mark: |
| 1.1.3   | :white_check_mark: |
| 1.2.1   | :white_check_mark: |

## Reporting a Vulnerability

To report a vulnerability in our code , please create a new issue / pull request (if you know how to fix it) and tell the vulnerability.

## When will vulnerability get Fixed ?

We will try to reach the limits which this extension and see if we find any issues but until then, feel free to report a vulnerability.
